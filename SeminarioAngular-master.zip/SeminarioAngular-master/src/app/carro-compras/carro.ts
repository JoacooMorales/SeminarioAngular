export interface carro {
    name: string,
    price :number,
    stock : number,
    total : number ;
}