import { Component } from '@angular/core';

@Component({
  selector: 'app-vinos-dx-about',
  standalone: true,
  imports: [],
  templateUrl: './vinos-dx-about.component.html',
  styleUrl: './vinos-dx-about.component.scss'
})
export class VinosDxAboutComponent {

}
