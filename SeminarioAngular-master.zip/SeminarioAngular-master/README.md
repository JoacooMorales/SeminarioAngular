# SeminarioAngular

ACLARACION : Se encuentra todo en la rama Master .

Esta pagina es bastante similar a Brewery pero con estilo de Vinos + estilos distintos y un "invento" de about en la segunda redireccion,
tengo una mala practica (mezcle palabras en ingles y español). 

Joaquin Morales - 44670547 - joacomora2014@gmail.com - Sede Tandil
